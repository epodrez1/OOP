﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oop_L3
{
    public partial class car
    {
        public void beep()
        {
            Console.WriteLine(" ~ BEEP!! ~ \n");
        }

    }
}
