﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LABA5
{
    public class Plans
    {
        public int Height { get; set; }

        public int Weight{ get; set; }

        
    }
}
