﻿using System;
public partial class Train
{
    public void tr()
        {
            Console.WriteLine("New train");
        }
}