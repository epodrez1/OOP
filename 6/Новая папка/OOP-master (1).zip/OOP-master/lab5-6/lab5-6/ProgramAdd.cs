﻿using lab5_6;
using System;
using System.Collections.Generic;
using System.Text;

namespace lab5_6
{
    class ProgramAdd
    {
        public partial class Car : Transport
        {
            public void Move()
            {
                Console.WriteLine("I am moving");
            }
        }
    }
}
