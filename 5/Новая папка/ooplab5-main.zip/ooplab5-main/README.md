# ooplab5
Inheritance, polymorphism, abstract classes and interfaces
